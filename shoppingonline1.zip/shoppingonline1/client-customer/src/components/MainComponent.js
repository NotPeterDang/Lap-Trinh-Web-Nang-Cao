import React, { Component } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

import Menu from './MenuComponent';
import Inform from './InformComponent';
import Home from './HomeComponent';
import Product from './ProductComponent';
import ProductDetail from './ProductDetailComponent';
import Signup from './SignupComponent';
import Active from './ActiveComponent';
import Login from './LoginComponent';
import Myprofile from './MyprofileComponent';
import Mycart from './MycartComponent';
import Myorders from './MyordersComponent';

class Main extends Component {
  render() {
    return (
      <div className="body-customer">
        <Menu />
        <Inform />

        <Routes>

          <Route path="/" element={<Navigate replace to="/home" />} />
          <Route path="/home" element={<Home />} />

          {/* route hiển thị sản phẩm theo category */}
          <Route path="/product/category/:cid" element={<Product />} />

          {/* route tìm kiếm sản phẩm theo keyword */}
          <Route path="/product/search/:keyword" element={<Product />} />

          {/* route xem chi tiết sản phẩm */}
          <Route path="/product/:id" element={<ProductDetail />} />

          {/* route signup */}
          <Route path="/signup" element={<Signup />} />

          {/* route active account */}
          <Route path="/active" element={<Active />} />

          {/* route login */}
          <Route path="/login" element={<Login />} />

          {/* route my profile */}
          <Route path="/myprofile" element={<Myprofile />} />

          {/* route my cart */}
          <Route path="/mycart" element={<Mycart />} />

          {/* route my orders */}
          <Route path="/myorders" element={<Myorders />} />

        </Routes>
      </div>
    );
  }
}

export default Main;