const express = require('express');
const router = express.Router();

// utils
const JwtUtil = require('../utils/JwtUtil');
const EmailUtil = require('../utils/EmailUtil'); // Đã thêm EmailUtil

// daos
const AdminDAO = require('../models/AdminDAO');
const CategoryDAO = require('../models/CategoryDAO');
const ProductDAO = require('../models/ProductDAO');
const OrderDAO = require('../models/OrderDAO');
const CustomerDAO = require('../models/CustomerDAO');

// ===== LOGIN API =====
router.post('/login', async function (req, res) {
  const username = req.body.username;
  const password = req.body.password;

  if (username && password) {
    const admin = await AdminDAO.selectByUsernameAndPassword(username, password);

    if (admin) {
      const token = JwtUtil.genToken(username, password);

      res.json({
        success: true,
        message: 'Authentication successful',
        token: token
      });
    } else {
      res.json({
        success: false,
        message: 'Incorrect username or password'
      });
    }
  } else {
    res.json({
      success: false,
      message: 'Please input username and password'
    });
  }
});

// ===== CHECK TOKEN API =====
router.get('/token', JwtUtil.checkToken, function (req, res) {
  const token =
    req.headers['x-access-token'] ||
    req.headers['authorization'];

  res.json({
    success: true,
    message: 'Token is valid',
    token: token
  });
});

// ================= CATEGORY API =================

router.get('/categories', JwtUtil.checkToken, async function (req, res) {
  try {
    const categories = await CategoryDAO.selectAll();
    res.json(categories);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/categories', JwtUtil.checkToken, async function (req, res) {
  try {
    const name = req.body.name;
    const category = { name: name };

    const result = await CategoryDAO.insert(category);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/categories/:id', JwtUtil.checkToken, async function (req, res) {
  try {
    const _id = req.params.id;
    const name = req.body.name;

    const category = { _id: _id, name: name };

    const result = await CategoryDAO.update(category);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/categories/:id', JwtUtil.checkToken, async function (req, res) {
  try {
    const _id = req.params.id;

    const result = await CategoryDAO.delete(_id);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ================= PRODUCT API =================

router.get('/products', JwtUtil.checkToken, async function (req, res) {
  try {
    let products = await ProductDAO.selectAll();

    const sizePage = 4;
    const noPages = Math.ceil(products.length / sizePage);

    let curPage = 1;
    if (req.query.page) {
      curPage = parseInt(req.query.page);
    }

    const offset = (curPage - 1) * sizePage;
    products = products.slice(offset, offset + sizePage);

    const result = {
      products: products,
      noPages: noPages,
      curPage: curPage
    };

    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/products', JwtUtil.checkToken, async function (req, res) {
  try {
    const name = req.body.name;
    const price = req.body.price;
    const cid = req.body.category;
    const image = req.body.image;

    const now = new Date().getTime();

    const product = {
      name: name,
      price: price,
      image: image,
      cdate: now,
      category: cid
    };

    const result = await ProductDAO.insert(product);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/products/:id', JwtUtil.checkToken, async function (req, res) {
  try {
    const _id = req.params.id;
    const name = req.body.name;
    const price = req.body.price;
    const cid = req.body.category;
    const image = req.body.image;

    const now = new Date().getTime();

    const product = {
      _id: _id,
      name: name,
      price: price,
      image: image,
      cdate: now,
      category: cid
    };

    const result = await ProductDAO.update(product);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/products/:id', JwtUtil.checkToken, async function (req, res) {
  try {
    const _id = req.params.id;

    const result = await ProductDAO.delete(_id);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ================= CUSTOMER API =================

router.get('/customers', JwtUtil.checkToken, async function (req, res) {
  try {
    const customers = await CustomerDAO.selectAll();
    res.json(customers);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/customers/deactive/:id', JwtUtil.checkToken, async function (req, res) {
  try {
    const _id = req.params.id;
    const token = req.body.token;
    const result = await CustomerDAO.active(_id, token, 0);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/customers/sendmail/:id', JwtUtil.checkToken, async function (req, res) {
  try {
    const _id = req.params.id;
    const cust = await CustomerDAO.selectByID(_id);
    if (cust) {
      const send = await EmailUtil.send(cust.email, cust._id, cust.token);
      if (send) {
        res.json({ success: true, message: 'Please check email' });
      } else {
        res.json({ success: false, message: 'Email failure' });
      }
    } else {
      res.json({ success: false, message: 'Not exists customer' });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ================= ORDER API =================

// GET ALL ORDERS
router.get('/orders', JwtUtil.checkToken, async function (req, res) {
  try {
    const orders = await OrderDAO.selectAll();
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET ORDERS BY CUSTOMER ID
router.get('/orders/customer/:cid', JwtUtil.checkToken, async function (req, res) {
  try {
    const _cid = req.params.cid;
    const orders = await OrderDAO.selectByCustID(_cid);
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// UPDATE ORDER STATUS
router.put('/orders/status/:id', JwtUtil.checkToken, async function (req, res) {
  try {
    const _id = req.params.id;
    const newStatus = req.body.status;

    const result = await OrderDAO.update(_id, newStatus);

    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== TEST API =====
router.get('/test', function (req, res) {
  res.json({ message: "ADMIN API WORKING" });
});

module.exports = router;