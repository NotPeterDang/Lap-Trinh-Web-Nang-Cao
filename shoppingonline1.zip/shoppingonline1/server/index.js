const express = require('express');
const path = require('path');
const cors = require('cors'); // Thêm cors để tránh lỗi Network Error từ React
const app = express();
const PORT = process.env.PORT || 3000;

// 1. MIDDLEWARES
app.use(cors()); // Cho phép React (port 3000) gọi API đến Server (port 3002)
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// 2. CÁC ROUTE API (Phải đặt TRƯỚC phần Deployment/Static)
app.get('/hello', (req, res) => {
  res.json({ message: 'Hello from server!' });
});

// Mount các router API
app.use('/api/admin', require('./api/admin.js'));
app.use('/api/customer', require('./api/customer.js'));


// 3. DEPLOYMENT & STATIC FILES (Cấu hình phục vụ giao diện React)

// --- Cấu hình cho ADMIN ---
// Phục vụ các file tĩnh (css, js, images) của admin
app.use('/admin', express.static(path.resolve(__dirname, '../client-admin/build')));

// Route này giúp React Router của Admin hoạt động (Refresh trang không bị 404)
app.get(/^\/admin\/(.*)/, (req, res) => {
  const filePath = path.resolve(__dirname, '../client-admin/build', 'index.html');
  res.sendFile(filePath, (err) => {
    if (err) {
      console.error("Lỗi gửi file Admin:", err);
      res.status(500).send("Không tìm thấy index.html của Admin. Hãy build lại client-admin!");
    }
  });
});

// --- Cấu hình cho CUSTOMER (Trang chủ) ---
// Phục vụ các file tĩnh của customer
app.use('/', express.static(path.resolve(__dirname, '../client-customer/build')));

// Bất kỳ đường dẫn nào còn lại sẽ trả về index.html của Customer
app.get(/^((?!\/api).)*$/, (req, res) => {
  res.sendFile(path.resolve(__dirname, '../client-customer/build', 'index.html'));
});

// 4. KHỞI CHẠY SERVER
app.listen(PORT, () => {
  console.log(`Server đang chạy tại: http://localhost:${PORT}`);
  console.log(`Admin panel: http://localhost:${PORT}/admin`);
});