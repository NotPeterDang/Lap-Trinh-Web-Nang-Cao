require('../utils/MongooseUtil');
const Models = require('./Models');

const CategoryDAO = {

  // Lấy tất cả category
  async selectAll() {
    const query = {};
    const categories = await Models.Category.find(query).exec();
    return categories;
  },

  // Lấy 1 category theo ID
  async selectByID(_id) {
    const category = await Models.Category.findById(_id).exec();
    return category;
  },

  // Thêm mới category
  async insert(category) {
    const mongoose = require('mongoose');

    category._id = new mongoose.Types.ObjectId();

    const result = await Models.Category.create(category);
    return result;
  },

  // Cập nhật category
  async update(category) {
    const newvalues = { name: category.name };

    const result = await Models.Category.findByIdAndUpdate(
      category._id,
      newvalues,
      { new: true }
    );

    return result;
  },

  // Xóa category theo ID
  async delete(_id) {
    const result = await Models.Category.findByIdAndDelete(_id);
    return result;
  }

};

module.exports = CategoryDAO;
