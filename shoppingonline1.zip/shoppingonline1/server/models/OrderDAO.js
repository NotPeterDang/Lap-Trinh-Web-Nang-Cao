require('../utils/MongooseUtil');
const Models = require('./Models');

const OrderDAO = {

  async insert(order) {
    const mongoose = require('mongoose');
    order._id = new mongoose.Types.ObjectId();

    const result = await Models.Order.create(order);
    return result;
  },

  async selectByCustID(_cid) {
    const query = { 'customer._id': _cid };
    const orders = await Models.Order.find(query).exec();
    return orders;
  },

  async selectAll() {
    const query = {};
    const mysort = { cdate: -1 };

    const orders = await Models.Order
      .find(query)
      .sort(mysort)
      .exec();

    return orders;
  },

  // ✅ THÊM HÀM NÀY
  async update(_id, newStatus) {
    const newvalues = { status: newStatus };

    const result = await Models.Order.findByIdAndUpdate(
      _id,
      newvalues,
      { new: true } // trả về dữ liệu sau khi update
    );

    return result;
  }

};

module.exports = OrderDAO;