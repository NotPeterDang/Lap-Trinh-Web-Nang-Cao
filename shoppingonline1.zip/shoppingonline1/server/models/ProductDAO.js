require('../utils/MongooseUtil');
const Models = require('./Models');

const ProductDAO = {

  async selectAll() {
    const query = {};
    const products = await Models.Product.find(query)
      .populate('category')
      .exec();
    return products;
  },

  async insert(product) {
    const mongoose = require('mongoose');

    product._id = new mongoose.Types.ObjectId();

    const result = await Models.Product.create(product);
    return result;
  },

  async selectByID(_id) {
    const product = await Models.Product.findById(_id)
      .populate('category')
      .exec();
    return product;
  },

  async update(product) {
    const newvalues = {
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category
    };

    const result = await Models.Product.findByIdAndUpdate(
      product._id,
      newvalues,
      { new: true }
    ).exec();

    return result;
  },

  async delete(_id) {
    const result = await Models.Product.findByIdAndDelete(_id);
    return result;
  },

  async selectTopNew(top) {
    const query = {};
    const mysort = { cdate: -1 };

    const products = await Models.Product.find(query)
      .sort(mysort)
      .limit(top)
      .exec();

    return products;
  },

  async selectTopHot(top) {
    const items = await Models.Order.aggregate([
      { $match: { status: 'APPROVED' } },
      { $unwind: '$items' },
      {
        $group: {
          _id: '$items.product._id',
          sum: { $sum: '$items.quantity' }
        }
      },
      { $sort: { sum: -1 } },
      { $limit: top }
    ]).exec();

    let products = [];

    for (const item of items) {
      const product = await ProductDAO.selectByID(item._id);
      products.push(product);
    }

    return products;
  },

  // ===== HÀM MỚI ĐƯỢC THÊM =====
  async selectByCatID(_cid) {
    const query = { 'category._id': _cid };
    const products = await Models.Product.find(query).exec();
    return products;
  }

};

module.exports = ProductDAO;
