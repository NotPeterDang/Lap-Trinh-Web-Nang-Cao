const MyConstants = {
  DB_SERVER: 'cluster0.qcyiaha.mongodb.net',
  DB_USER: 'ggar97270_db_user',
  DB_PASS: 'cRinwoyHGFry8nzo',
  DB_DATABASE: 'shoponline',

  // Microsoft mail service
  EMAIL_USER: 'skjdfoasijfd@hotmail.com',
  EMAIL_PASS: '01255626200m',

  JWT_SECRET: 'abc',
  JWT_EXPIRES: '86400000'   // in milliseconds
};

module.exports = MyConstants;
